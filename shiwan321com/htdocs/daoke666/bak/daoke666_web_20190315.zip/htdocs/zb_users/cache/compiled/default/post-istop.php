<?php  /* Template Name:列表页单条置顶文章 */  ?>
<div class="post istop">
	<h2 class="post-title">[<?php  echo $lang['msg']['top'];  ?>]<a href="<?php  echo $article->Url;  ?>"><?php  echo $article->Title;  ?></a></h2>
</div>