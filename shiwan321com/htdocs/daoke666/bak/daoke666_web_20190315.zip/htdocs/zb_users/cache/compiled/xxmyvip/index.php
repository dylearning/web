
<?php if ($type=='index') { ?>
<?php  include $this->GetTemplate('default');  ?>
<?php }else{  ?>
<?php  include $this->GetTemplate('catalog');  ?>
<?php } ?>