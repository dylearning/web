<?php
 echo'<meta charset="UTF-8"><div style="text-align:center;padding:60px 0;font-size:15px;"><h2 style="font-size:60px;margin-bottom:32px;">非法访问</h2></div>';
 die();
 ?><div class="firstreed2">
<a target="_blank" href="{$article.Url}" title="{$article.Title}"><div id="zhaiyaotu2"><img alt="{$article.Title}" src="{$article.Metas.prosptp}" /></div><h2>{$article.Title}</h2><small><span class="jiage"><strong class="bh">¥ {$article.Metas.procpy5}</strong></span>{$article.Metas.prospmc}</small></a>
</div>